import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

export default function App() {
  const [input, setInput] = useState('');
  const [isDumped, setIsDumped] = useState(false);

  const handleDump = () => {
    if (!input.trim()) return;
    setIsDumped(true);
    setTimeout(() => {
      setInput('');
      setIsDumped(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-blue-50 to-indigo-100 flex items-center justify-center text-center px-4">
      <div className="max-w-xl w-full">
        <h1 className="text-5xl font-bold text-gray-800 mb-8">Scream Dump</h1>

        <AnimatePresence>
          {!isDumped && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col sm:flex-row items-center justify-center gap-4"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="Enter your thoughts..."
                className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-400 text-gray-700"
              />
              <button
                onClick={handleDump}
                className="px-6 py-3 bg-indigo-500 text-white rounded-lg hover:bg-indigo-600 transition"
              >
                Dump
              </button>
            </motion.div>
          )}

          {isDumped && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.5 }}
              className="text-lg text-indigo-600 mt-4"
            >
              Disappeared into the void.
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
